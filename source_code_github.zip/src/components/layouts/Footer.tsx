export default function Footer(): JSX.Element {
  return (
    <footer style={{ textAlign: "center", padding: "20px 0", opacity: 0.7 }}>
      © {new Date().getFullYear()} CredIT. All rights reserved.
    </footer>
  );
}