import React from 'react';
import { motion } from 'framer-motion';
import { Card } from '../ui/Card';
import { Wallet, PieChart, Lock, Smartphone } from 'lucide-react';
import creditScoreImg from '../../assets/credit-score.jpg';
import payRequestImg from '../../assets/pay_request2.png';
import splitBillsImg from '../../assets/split_bills_5.png';
import webPic1Img from '../../assets/web_pic1.png';
import webPic2Img from '../../assets/web_pic2.png';

const features = [
  {
    icon: Wallet,
    title: 'Smart Wallet',
    description: 'Manage all your digital assets in one secure place with real-time tracking.',
  },
  {
    icon: PieChart,
    title: 'Analytics',
    description: 'Deep insights into your spending habits with AI-powered recommendations.',
  },
  {
    icon: Lock,
    title: 'Bank-Grade Security',
    description: 'Your data is protected by military-grade encryption and biometric security.',
  },
  {
    icon: Smartphone,
    title: 'Mobile First',
    description: 'Experience full functionality on the go with our top-rated mobile app.',
  },
];

export const Features = ({ showPayRequest = true, showSplitBills = true }: { showPayRequest?: boolean; showSplitBills?: boolean }) => {
  return (
    <section className="py-24 relative">
      {/* Background Elements */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-primary/5 to-transparent pointer-events-none" />
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center mb-16">
          
          {/* Unified 50% Instant Loans Section */}
          <motion.div 
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="relative bg-black/30 backdrop-blur-3xl rounded-[3rem] border border-white/10 p-8 md:p-16 mb-24 overflow-hidden group max-w-6xl mx-auto"
          >
            {/* Background Effects */}
            <div className="absolute inset-0 bg-gradient-to-b from-primary/5 via-transparent to-transparent opacity-50 pointer-events-none" />
            <div className="absolute -top-24 -right-24 w-96 h-96 bg-primary/20 rounded-full blur-3xl opacity-30 group-hover:opacity-50 transition duration-1000" />
            <div className="absolute -bottom-24 -left-24 w-96 h-96 bg-orange-600/20 rounded-full blur-3xl opacity-30 group-hover:opacity-50 transition duration-1000" />
            
            <div className="relative z-10 flex flex-col items-center">
              {/* Images Row */}
              <div className="flex flex-col md:flex-row justify-center items-center gap-8 md:gap-16 mb-16 w-full">
                {/* QR Code */}
                <motion.div 
                  whileHover={{ scale: 1.05, rotate: -2 }}
                  transition={{ type: "spring", stiffness: 300 }}
                  className="relative group/img cursor-pointer"
                >
                  <div className="absolute -inset-1 bg-gradient-to-r from-orange-500 via-red-500 to-orange-500 rounded-3xl blur-xl opacity-40 group-hover/img:opacity-80 transition duration-500 animate-pulse"></div>
                  <div className="relative bg-black/40 backdrop-blur-2xl p-6 rounded-3xl border border-white/10 ring-1 ring-white/20 shadow-2xl overflow=visible">
                    <div className="relative w-fit mx-auto overflow=visible">
                      <img 
                        src={webPic1Img} 
                        alt="Feature Preview" 
                        className="h-48 md:h-64 w-auto object-contain drop-shadow-2xl rounded-2xl"
                      />
                      <motion.div 
                        initial={{ opacity: 0, y: 10 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.5 }}
                        className="absolute bottom-2 left-[9.0%] -translate-x-1/2 bg-gradient-to-r from-orange-500 to-red-600 text-white text-xs font-bold px-6 py-2 rounded-full shadow-lg border border-white/20 flex items-center gap-2 whitespace-nowrap z-30"
                      >
                        <span className="relative flex h-2 w-2">
                          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-75"></span>
                          <span className="relative inline-flex rounded-full h-2 w-2 bg-white"></span>
                        </span>
                        SCAN TO PAY
                      </motion.div>
                    </div>
                  </div>
                </motion.div>

                {/* Extra Feature Image */}
                <motion.div 
                  whileHover={{ scale: 1.05, rotate: 2 }}
                  transition={{ type: "spring", stiffness: 300 }}
                  className="relative group/img cursor-pointer"
                >
                  <div className="absolute -inset-1 bg-gradient-to-r from-orange-500 via-red-500 to-orange-500 rounded-3xl blur-xl opacity-40 group-hover/img:opacity-80 transition duration-500 animate-pulse"></div>
                  <div className="relative bg-black/40 backdrop-blur-2xl p-6 rounded-3xl border border-white/10 ring-1 ring-white/20 shadow-2xl">
                    <img 
                      src={webPic2Img} 
                      alt="Feature Preview" 
                      className="h-48 md:h-64 w-auto object-contain drop-shadow-2xl rounded-2xl"
                    />
                  </div>
                </motion.div>
              </div>

              {/* Text Content */}
              <div className="text-center max-w-4xl mx-auto">
                <motion.span 
                  initial={{ scale: 0.5, opacity: 0 }}
                  whileInView={{ scale: 1, opacity: 1 }}
                  transition={{ delay: 0.3, type: "spring", bounce: 0.5 }}
                  className="block text-8xl md:text-[10rem] font-black text-transparent bg-clip-text bg-gradient-to-b from-primary to-orange-600 mb-8 tracking-tighter drop-shadow-2xl"
                >
                  50%
                </motion.span>
                <motion.h3 
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5 }}
                  className="text-3xl md:text-5xl font-bold text-white leading-tight"
                >
                  Get Instant Loans on Every UPI Payment Made for Purchases
                </motion.h3>
              </div>
            </div>
          </motion.div>

          {/* Pay Request Section */}
          {showPayRequest && (
          <motion.div 
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="mb-24 relative group max-w-5xl mx-auto"
          >
             <div className="absolute -inset-0.5 bg-gradient-to-l from-orange-500/50 to-red-600/50 rounded-3xl blur opacity-30 group-hover:opacity-60 transition duration-1000 group-hover:duration-200"></div>
             <div className="relative bg-black/40 backdrop-blur-xl border border-white/10 rounded-3xl p-8 md:p-12 flex flex-col md:flex-row-reverse items-center gap-12 overflow-hidden">
                
                <div className="flex-1 text-left space-y-6">
                   <motion.h3 
                     initial={{ opacity: 0, x: -20 }}
                     whileInView={{ opacity: 1, x: 0 }}
                     transition={{ delay: 0.1 }}
                     className="text-3xl md:text-5xl font-bold leading-tight bg-clip-text text-transparent bg-gradient-to-br from-white via-white to-white/60"
                   >
                     Payments made easy even when your bank isn’t
                   </motion.h3>
                   <motion.p 
                     initial={{ opacity: 0, x: -20 }}
                     whileInView={{ opacity: 1, x: 0 }}
                     transition={{ delay: 0.2 }}
                     className="text-xl text-muted-foreground leading-relaxed"
                   >
                     With Pay Request, you can instantly ask someone else to pay for you if your bank is down, there’s a technical issue, or your balance is low.
                   </motion.p>
                   <motion.div 
                     initial={{ opacity: 0, x: -20 }}
                     whileInView={{ opacity: 1, x: 0 }}
                     transition={{ delay: 0.3 }}
                     className="flex items-center gap-4 text-sm font-medium text-primary"
                   >
                      <span className="flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full bg-primary"></span> Instant Requests
                      </span>
                      <span className="flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full bg-primary"></span> 24/7 Availability
                      </span>
                   </motion.div>
                </div>

                <div className="flex-1 relative w-full">
                   <motion.div 
                     className="relative rounded-2xl overflow-hidden shadow-2xl border border-white/10 group-hover:scale-[1.02] transition-transform duration-500"
                     animate={{ y: [0, -10, 0] }}
                     transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
                   >
                      <div className="absolute inset-0 bg-gradient-to-tr from-primary/20 to-transparent mix-blend-overlay z-10"></div>
                      <img src={payRequestImg} alt="Pay Request Interface" className="w-full h-auto object-cover" />
                      
                      {/* Modernized Overlay to rebrand 'Request to pay' */}
                      <motion.div 
                        initial={{ opacity: 0, scale: 0.9 }}
                        whileInView={{ opacity: 1, scale: 1 }}
                        transition={{ delay: 0.3, duration: 0.5 }}
                        className="absolute bottom-6 left-6 right-6 bg-black/60 backdrop-blur-xl border border-white/20 p-4 rounded-2xl z-20 flex items-center justify-between"
                      >
                        <div>
                          <p className="text-xs text-primary font-medium uppercase tracking-wider">Feature</p>
                          <p className="text-lg font-bold text-white">Pay Request</p>
                        </div>
                        <div className="h-10 w-10 rounded-full bg-gradient-to-br from-primary to-orange-600 flex items-center justify-center shadow-lg shadow-primary/20">
                          <Wallet className="w-5 h-5 text-white" />
                        </div>
                      </motion.div>
                   </motion.div>
                   {/* Decorative elements */}
                   <motion.div 
                     animate={{ scale: [1, 1.1, 1], opacity: [0.5, 0.8, 0.5] }}
                     transition={{ duration: 4, repeat: Infinity }}
                     className="absolute -top-6 -left-6 w-24 h-24 bg-orange-500/20 rounded-full blur-2xl"
                   ></motion.div>
                   <motion.div 
                     animate={{ scale: [1, 1.2, 1], opacity: [0.5, 0.8, 0.5] }}
                     transition={{ duration: 5, repeat: Infinity, delay: 1 }}
                     className="absolute -bottom-6 -right-6 w-32 h-32 bg-red-500/20 rounded-full blur-2xl"
                   ></motion.div>
                </div>

             </div>
          </motion.div>
          )}

          {/* Split Bills Section */}
          {showSplitBills && (
          <motion.div 
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="mb-24 relative group max-w-5xl mx-auto"
          >
             <div className="absolute -inset-0.5 bg-gradient-to-r from-primary/50 to-orange-600/50 rounded-3xl blur opacity-30 group-hover:opacity-60 transition duration-1000 group-hover:duration-200"></div>
             <div className="relative bg-black/40 backdrop-blur-xl border border-white/10 rounded-3xl p-8 md:p-12 flex flex-col md:flex-row items-center gap-12 overflow-hidden">
                
                <div className="relative w-full md:w-1/3 max-w-sm rounded-2xl overflow-hidden shadow-2xl border border-white/30 group-hover:scale-[1.02] transition-transform duration-500 flex-shrink-0">
                   <img src={splitBillsImg} alt="Split Bills Interface" className="w-full h-auto object-cover" />
                </div>

                <div className="flex-1 space-y-6 relative z-20 text-left">
                   <motion.h3 
                     initial={{ opacity: 0, x: 20 }}
                     whileInView={{ opacity: 1, x: 0 }}
                     transition={{ delay: 0.2 }}
                     className="text-3xl md:text-5xl font-bold leading-tight bg-clip-text text-transparent bg-gradient-to-br from-white via-white to-white/60"
                   >
                     Split bills in seconds
                   </motion.h3>
                   <motion.p 
                     initial={{ opacity: 0, x: 20 }}
                     whileInView={{ opacity: 1, x: 0 }}
                     transition={{ delay: 0.3 }}
                     className="text-xl text-muted-foreground leading-relaxed"
                   >
                     Everyone pays their share directly to the merchant or host, no chasing required.
                   </motion.p>
                </div>

             </div>
          </motion.div>
          )}

          {/* Credit Score Section */}
          <div className="mb-24 relative group max-w-5xl mx-auto">
             <div className="absolute -inset-0.5 bg-gradient-to-r from-primary/50 to-purple-600/50 rounded-3xl blur opacity-30 group-hover:opacity-60 transition duration-1000 group-hover:duration-200"></div>
             <div className="relative bg-black/40 backdrop-blur-xl border border-white/10 rounded-3xl p-8 md:p-12 flex flex-col md:flex-row items-center gap-12 overflow-hidden">
                <div className="flex-1 text-left space-y-6">
                   <h3 className="text-3xl md:text-5xl font-bold leading-tight bg-clip-text text-transparent bg-gradient-to-br from-white via-white to-white/60">
                     Build your Credit Score from Scratch
                   </h3>
                   <p className="text-xl text-muted-foreground leading-relaxed">
                     Keep a Healthy Credit Score and History. Our advanced algorithms help you track, improve, and maintain your financial health effortlessly.
                   </p>
                   <div className="flex items-center gap-4 text-sm font-medium text-primary">
                      <span className="flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full bg-primary"></span> Real-time Updates
                      </span>
                      <span className="flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full bg-primary"></span> Smart Insights
                      </span>
                   </div>
                </div>
                <div className="flex-1 relative w-full">
                   <div className="relative rounded-2xl overflow-hidden shadow-2xl border border-white/10 group-hover:scale-[1.02] transition-transform duration-500">
                      <div className="absolute inset-0 bg-gradient-to-tr from-primary/20 to-transparent mix-blend-overlay z-10"></div>
                      <img src={creditScoreImg} alt="Credit Score Dashboard" className="w-full h-auto object-cover" />
                   </div>
                   {/* Decorative elements */}
                   <div className="absolute -top-6 -right-6 w-24 h-24 bg-primary/20 rounded-full blur-2xl"></div>
                   <div className="absolute -bottom-6 -left-6 w-32 h-32 bg-purple-500/20 rounded-full blur-2xl"></div>
                </div>
             </div>
          </div>

          <h2 className="text-3xl md:text-5xl font-bold mb-6">Why Choose CredIT?</h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            We provide the tools you need to take control of your financial future.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <Card key={index} className="p-6 group hover:-translate-y-1 transition-transform duration-300" gradient>
              <div className="h-14 w-14 rounded-2xl bg-primary/10 flex items-center justify-center mb-6 group-hover:bg-primary group-hover:text-white transition-all duration-300 shadow-inner">
                <feature.icon className="h-7 w-7 text-primary group-hover:text-white transition-colors" />
              </div>
              <h3 className="text-xl font-bold mb-3">{feature.title}</h3>
              <p className="text-muted-foreground leading-relaxed">{feature.description}</p>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};
