export default function Footer(): JSX.Element {
  return (
    <footer className="py-8 border-t border-white/10 mt-20">
      <div className="container mx-auto px-4 text-center text-muted-foreground text-sm">
        © {new Date().getFullYear()} CredIT. All rights reserved.
      </div>
    </footer>
  );
}