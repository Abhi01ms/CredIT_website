import React, { useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { Navbar } from '../components/layouts/Navbar';
import { Hero } from '../components/sections/Hero';
import { Features } from '../components/sections/Features';
import { Contact } from '../components/sections/Contact';

const Home = () => {
  const location = useLocation();

  useEffect(() => {
    // Check if we need to scroll to contact section (from navigation state)
    if (location.state && (location.state as any).scrollToContact) {
      const contactSection = document.getElementById('contact');
      if (contactSection) {
        // Small delay to ensure DOM is ready
        setTimeout(() => {
          contactSection.scrollIntoView({ behavior: 'smooth' });
        }, 100);
      }
      
      // Clear the state to prevent scrolling on subsequent renders
      window.history.replaceState({}, document.title);
    }
  }, [location]);

  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      <Navbar />
      <main>
        <Hero />
        <Features showPayRequest={false} showSplitBills={false} />
        <Contact showForm={false} />
      </main>
     
    </div>
  );
};

export default Home;
