import React from 'react';
import { motion } from 'framer-motion';
import { Navbar } from '../components/layouts/Navbar';
import { Card } from '../components/ui/Card';
import { Target, Users, Zap, Shield } from 'lucide-react';
import { Contact } from '../components/sections/Contact';

const About = () => {
  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      <Navbar />
      
      <main className="pt-32 pb-20">
        <div className="container mx-auto px-4">
          {/* Hero Section */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center mb-20"
          >
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              About <span className="text-gradient">CredIT</span>
            </h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Empowering financial growth through cutting-edge technology and UPI-enabled digital lending solutions.
            </p>
          </motion.div>

          {/* Main Content */}
          <div className="grid lg:grid-cols-2 gap-12 items-start mb-24">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="space-y-6 text-lg text-muted-foreground"
            >
              <p>
                Empowering financial growth through cutting-edge technology, our company delivers seamless, UPI-enabled digital lending solutions tailored for India's rapidly evolving digital economy. By leveraging the strength and security of India's UPI infrastructure, we simplify access to credit, making it fast, reliable, and hassle-free for individuals and small businesses seeking flexible and timely financial support.
              </p>
              <p>
                Our platform is built on advanced data analytics and intelligent decision-making systems that deeply understand user behavior and financial needs. This enables instant loan approvals, customized credit offerings, and clear, transparent repayment options all accessible with just a few taps on a mobile phone. By eliminating lengthy paperwork and complex processes, we ensure a smooth, intuitive borrowing experience that puts users in control of their finances.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="grid gap-6"
            >
              <Card className="p-6" gradient>
                <div className="flex items-start gap-4">
                  <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                    <Target className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold mb-2">Our Mission</h3>
                    <p className="text-muted-foreground">
                      Driven by innovation, trust, and customer centricity, we are committed to expanding financial inclusion across India by serving both underbanked and digitally savvy users. We aim to bridge the credit gap by offering responsible lending solutions that are secure, compliant, and designed for long term financial well being.
                    </p>
                  </div>
                </div>
              </Card>

              <Card className="p-6" gradient>
                <div className="flex items-start gap-4">
                  <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                    <Users className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold mb-2">Who We Serve</h3>
                    <p className="text-muted-foreground">
                      Whether you are a student managing education expenses, an entrepreneur launching a new venture, a small business owner scaling operations, or a consumer handling everyday financial needs, our UPI-based lending solutions provide the confidence and convenience to grow, invest, and achieve your goals.
                    </p>
                  </div>
                </div>
              </Card>
            </motion.div>
          </div>

          {/* Values Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center max-w-4xl mx-auto"
          >
            <h2 className="text-3xl font-bold mb-12">Our Core Values</h2>
            <div className="grid md:grid-cols-3 gap-8">
              <div className="p-6 rounded-xl bg-secondary/30 border border-white/5">
                <div className="h-12 w-12 rounded-full bg-blue-500/10 flex items-center justify-center mx-auto mb-4">
                  <Shield className="h-6 w-6 text-blue-500" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Trust & Security</h3>
                <p className="text-sm text-muted-foreground">
                  Built on India's secure UPI infrastructure for safe transactions.
                </p>
              </div>
              <div className="p-6 rounded-xl bg-secondary/30 border border-white/5">
                <div className="h-12 w-12 rounded-full bg-orange-500/10 flex items-center justify-center mx-auto mb-4">
                  <Zap className="h-6 w-6 text-orange-500" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Innovation</h3>
                <p className="text-sm text-muted-foreground">
                  Leveraging advanced analytics for instant approvals.
                </p>
              </div>
              <div className="p-6 rounded-xl bg-secondary/30 border border-white/5">
                <div className="h-12 w-12 rounded-full bg-green-500/10 flex items-center justify-center mx-auto mb-4">
                  <Users className="h-6 w-6 text-green-500" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Inclusivity</h3>
                <p className="text-sm text-muted-foreground">
                  Serving both underbanked and digitally savvy users.
                </p>
              </div>
            </div>
            
            <p className="mt-12 text-lg font-medium text-primary">
              With transparency, simplicity, and reliability at our core, we are proud to support India's vision of a truly inclusive and digitally empowered financial future.
            </p>
          </motion.div>
        </div>
        <Contact showHeader={false} showForm={false} />
      </main>

      
    </div>
  );
};

export default About;
