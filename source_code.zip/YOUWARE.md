# CredIT - Fintech Web Application

This is a modern fintech web application built with React 18, TypeScript, Vite, and Tailwind CSS for "CredIT".

## Project Overview

- **Name**: CredIT
- **Theme**: Premium dark aesthetic with Orange primary accents, glassmorphism, and subtle gradients.
- **Key Features**:
  - Responsive Landing Page with 3D-style Hero section.
  - Features page with modern app showcase (iPhone 15 Pro style CSS mockup) and detailed feature list.
  - About Us page with company mission and values.
  - Pricing page with transparent fee structure.
  - Contact section (reusable, configurable).
  - Smooth scrolling and navigation.

## Development Commands

- **Install dependencies**: `npm install`
- **Build project**: `npm run build`
- **Preview build**: `npm run preview`
- **Dev server**: `npm run dev` (Note: Use `npm run build` for production verification)

## Architecture

### Key Components
- `src/pages/Features.tsx`: Features page containing the `ModernPhoneMockup` component (CSS-based iPhone 15 Pro frame), features grid, and contact information section.
- `src/components/sections/Contact.tsx`: Reusable contact section. Supports `showHeader` and `showForm` props to toggle visibility of the header and the contact form. Used in Home (full), Pricing (info only), About (info only), and Features (info only).
- `src/components/sections/Hero.tsx`: Hero section with animated credit card and custom logo.
- `src/components/sections/Features.tsx`: Reusable features grid section with glassmorphic cards, unified "50% Instant Loans" showcase card, optional "Pay Request" and "Split Bills" sections, "Credit Score" feature showcase (placed before features grid), and the features grid itself.
- `src/components/layouts/Navbar.tsx`: Responsive navigation bar with advanced blur and transparency.

### State Management
- `src/store/useAppStore.ts`: Zustand store for managing UI state (e.g., mobile menu).

### Styling
- Tailwind CSS with custom configuration in `tailwind.config.js`.
- Global styles in `src/index.css` (includes custom gradients, glass-card utility, and phone frame styles).
- Framer Motion for animations.
- **Text Gradient**: Use `.text-gradient` class for the brand's orange-to-red text gradient (e.g., used in Hero title). For `h1` headings, wrap the text in a `span` and apply the gradient classes (`bg-clip-text text-transparent bg-gradient-to-r from-orange-400 via-orange-500 to-red-600`) to ensure proper rendering.

## Assets
- Logos: `src/assets/CIT_logo6.png`, `src/assets/CIT_logo6_nav.png`.
- Images: `src/assets/splash_SS.png` (App mockup used in Features page), `src/assets/credit-score.jpg`, `src/assets/pay_request2.png` (Pay Request feature), `src/assets/split_bills_5.png` (Split Bills feature), `src/assets/qr_code_orange.png` (QR Code in Features section), `src/assets/ex_sss.png` (Extra feature image in Features section).
