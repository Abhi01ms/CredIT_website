import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Navbar } from '../components/layouts/Navbar';
import { Features as FeaturesSection } from '../components/sections/Features';
import { Contact } from '../components/sections/Contact';
import appImage from '../assets/splash_SS.png'; 

const ModernPhoneMockup = ({ src }: { src: string }) => {
  return (
    <div className="relative">
      {/* Outer Glow */}
      <div className="absolute -inset-1 bg-gradient-to-r from-primary/30 to-purple-500/30 rounded-[3rem] blur-2xl opacity-50" />
      
      {/* Phone Chassis */}
      <div className="relative w-[320px] h-[650px] bg-[#1a1a1a] rounded-[3rem] shadow-[0_0_0_2px_#333,0_0_0_6px_#1a1a1a,0_20px_50px_-10px_rgba(0,0,0,0.5)] overflow-hidden border-4 border-[#333]">
        
        {/* Side Buttons */}
        <div className="absolute top-24 -left-[6px] w-[4px] h-8 bg-[#2a2a2a] rounded-l-md" /> {/* Mute */}
        <div className="absolute top-36 -left-[6px] w-[4px] h-14 bg-[#2a2a2a] rounded-l-md" /> {/* Vol Up */}
        <div className="absolute top-52 -left-[6px] w-[4px] h-14 bg-[#2a2a2a] rounded-l-md" /> {/* Vol Down */}
        <div className="absolute top-40 -right-[6px] w-[4px] h-20 bg-[#2a2a2a] rounded-r-md" /> {/* Power */}

        {/* Screen Bezel */}
        <div className="absolute inset-[6px] bg-black rounded-[2.5rem] overflow-hidden">
          
          {/* Dynamic Island */}
          <div className="absolute top-3 left-1/2 -translate-x-1/2 w-[100px] h-[28px] bg-black rounded-full z-50 flex items-center justify-center">
            <div className="w-2 h-2 rounded-full bg-[#1a1a1a] ml-auto mr-2" /> {/* Camera lens hint */}
          </div>

          {/* Screen Content */}
          <div className="relative w-full h-full bg-gray-900">
            <img 
              src={src} 
              alt="CredIT App Screen" 
              className="w-full h-full object-cover brightness-110 contrast-125 saturate-[1.15] filter"
              style={{ imageRendering: 'auto' }}
            />
            
            {/* Glass Reflection/Glare */}
            <div className="absolute inset-0 bg-gradient-to-tr from-white/5 via-transparent to-white/5 pointer-events-none z-20 mix-blend-overlay opacity-40" />
            <div className="absolute -inset-full bg-gradient-to-r from-transparent via-white/5 to-transparent rotate-45 translate-x-[-100%] animate-shimmer pointer-events-none z-20 opacity-30" />
          </div>
        </div>
      </div>
    </div>
  );
};

const FeaturesPage = () => {
  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      <Navbar />
      
      <main className="pt-32 pb-20">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center mb-24">
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              className="relative z-10"
            >
              <h1 className="text-5xl font-bold tracking-tight mb-6">
                <span className="bg-clip-text text-transparent bg-gradient-to-r from-orange-400 via-orange-500 to-red-600">CredIT</span>
              </h1>
              
              <h2 className="text-3xl md:text-5xl font-bold mb-6 leading-tight bg-clip-text text-transparent bg-gradient-to-r from-white to-white/60">
                Most Hassle-Free App with Easy and Hassle-Free Navigation and Hassle-Free Features
              </h2>
              <p className="text-xl text-muted-foreground leading-relaxed max-w-xl">
                Experience the future of digital lending with our intuitive mobile application. Designed for simplicity, speed, and security.
              </p>
              
              <div className="mt-8 flex gap-4">
                <button className="px-8 py-3 rounded-full bg-primary text-primary-foreground font-semibold hover:bg-primary/90 transition-all shadow-lg shadow-primary/25">
                  Download Now
                </button>
                <Link to="/about" className="px-8 py-3 rounded-full bg-secondary text-secondary-foreground font-semibold hover:bg-secondary/80 transition-all border border-white/10">
                  Learn More
                </Link>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="relative flex justify-center perspective-1000"
            >
               {/* Background Glow */}
               <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[140%] h-[140%] bg-primary/10 blur-[120px] rounded-full pointer-events-none" />
               
               <div className="relative transform rotate-[-5deg] hover:rotate-0 transition-transform duration-700 ease-out hover:scale-105">
                  <ModernPhoneMockup src={appImage} />
               </div>
            </motion.div>
          </div>
        </div>

        <FeaturesSection />
        <Contact showForm={false} showHeader={false} />
      </main>
      
      <footer className="py-8 border-t border-white/10 mt-20">
        <div className="container mx-auto px-4 text-center text-muted-foreground text-sm">
          © 2025 CredIT. All rights reserved.
        </div>
      </footer>
    </div>
  );
};

export default FeaturesPage;
