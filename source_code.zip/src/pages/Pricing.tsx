import React from 'react';
import { motion } from 'framer-motion';
import { Navbar } from '../components/layouts/Navbar';
import { Card } from '../components/ui/Card';
import { Check, AlertCircle } from 'lucide-react';
import { Contact } from '../components/sections/Contact';

const Pricing = () => {
  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      <Navbar />
      
      <main className="pt-32 pb-20">
        <div className="container mx-auto px-4">
          {/* Hero Section */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center mb-20"
          >
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Transparent <span className="text-gradient">Pricing</span>
            </h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              No hidden fees. No surprises. Just clear, upfront charges for your peace of mind.
            </p>
          </motion.div>

          {/* Charges Section */}
          <div className="max-w-4xl mx-auto mb-24">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="grid gap-8"
            >
              <Card className="p-8" gradient>
                <h2 className="text-2xl font-bold mb-8">Charges & Fees</h2>
                
                <div className="space-y-8">
                  <div className="flex items-start gap-4">
                    <div className="h-10 w-10 rounded-full bg-green-500/10 flex items-center justify-center shrink-0">
                      <Check className="h-5 w-5 text-green-500" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold mb-2">Upfront Transparency</h3>
                      <p className="text-muted-foreground">
                        For each borrowing, charges will be shown upfront during the transaction and Key Facts Statement (KFS) will be provided for each loan. You'll always know exactly what you're paying before you commit.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <div className="h-10 w-10 rounded-full bg-orange-500/10 flex items-center justify-center shrink-0">
                      <AlertCircle className="h-5 w-5 text-orange-500" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold mb-2">Penal Charges</h3>
                      <p className="text-muted-foreground">
                        For loans, a fee of ₹500 or 20% of the overdue EMI (whichever is lower) will be charged on each overdue EMI. Please refer to your Key Facts Statement (KFS) for detailed terms and conditions regarding late payments.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="mt-8 pt-8 border-t border-white/10 text-center">
                  <p className="text-sm text-muted-foreground">
                    All charges are inclusive of GST
                  </p>
                </div>
              </Card>
            </motion.div>
          </div>
        </div>

        {/* Contact Section */}
        <Contact showHeader={false} showForm={false} />
      </main>

      <footer className="py-8 border-t border-white/10">
        <div className="container mx-auto px-4 text-center text-muted-foreground text-sm">
          © 2025 CredIT. All rights reserved.
        </div>
      </footer>
    </div>
  );
};

export default Pricing;
