import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Button } from '../ui/Button';
import { ArrowRight, Shield, Globe, Zap } from 'lucide-react';
import citLogo from '../../assets/CIT_logo6.png';

export const Hero = () => {
  return (
    <section className="relative pt-32 pb-20 overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary/20 via-background to-background" />
      <div className="container mx-auto px-4 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-5xl md:text-7xl font-bold leading-tight mb-6">
              The Future of <br />
              <span className="text-gradient">Digital Credit</span>
            </h1>
            <p className="text-xl text-muted-foreground mb-8 max-w-lg">
              Experience seamless financial freedom with our next-generation credit platform. 
              Secure, global, and instant.
            </p>
            <div className="flex flex-wrap gap-4">
              <Button size="lg" className="group">
                Get Started 
                <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Button>
              <Link to="/about">
                <Button variant="outline" size="lg">
                  Learn More
                </Button>
              </Link>
            </div>
            
            <div className="mt-12 flex gap-8 text-muted-foreground">
              <div className="flex items-center gap-2">
                <Shield className="h-5 w-5 text-primary" />
                <span>Secure</span>
              </div>
              <div className="flex items-center gap-2">
                <Globe className="h-5 w-5 text-primary" />
                <span>Global</span>
              </div>
              <div className="flex items-center gap-2">
                <Zap className="h-5 w-5 text-primary" />
                <span>Instant</span>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative"
          >
            <div className="relative z-10 transform rotate-[-12deg] hover:rotate-0 transition-transform duration-500">
              <div className="w-full aspect-[1.586] rounded-2xl bg-gradient-to-br from-orange-500 to-red-600 p-8 shadow-2xl border border-white/10 backdrop-blur-xl overflow-hidden relative">
                {/* Background Image */}
                <img 
                  src={citLogo} 
                  alt="CIT Logo" 
                  className="absolute inset-0 w-full h-full object-cover opacity-20 mix-blend-overlay"
                />
                
                <div className="relative z-10 flex flex-col justify-between h-full">
                  <div className="flex justify-between items-start">
                    <div className="h-12 w-16 bg-white/20 rounded-md backdrop-blur-md flex items-center justify-center">
                      <div className="w-8 h-8 rounded-full bg-yellow-400/50" />
                      <div className="w-8 h-8 rounded-full bg-red-400/50 -ml-4" />
                    </div>
                    <div className="text-white/80 font-mono text-lg tracking-widest">**** 4242</div>
                  </div>
                  
                  <div className="space-y-1">
                    <div className="text-white/60 text-xs uppercase tracking-wider font-medium">Current Balance</div>
                    <div className="text-white text-4xl font-bold tracking-tight">₹24,500.00</div>
                  </div>
                  
                  <div className="flex justify-between items-end">
                    <div className="text-white/80 font-medium"></div>
                    <div className="text-white/80 font-mono text-sm">EXP 12/28</div>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Decorative elements */}
            <div className="absolute -top-20 -right-20 w-64 h-64 bg-primary/30 rounded-full blur-3xl" />
            <div className="absolute -bottom-20 -left-20 w-64 h-64 bg-orange-500/30 rounded-full blur-3xl" />
          </motion.div>
        </div>
      </div>
    </section>
  );
};
